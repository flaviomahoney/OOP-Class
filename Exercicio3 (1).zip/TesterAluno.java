import java.util.Scanner;

public class TesterAluno{
    public static void main(String[] args) {
      Scanner teclado = new Scanner(System.in);

      Aluno aluno = new Aluno();

      System.out.println("Nome:");
      aluno.setNome(teclado.next() );
        
      System.out.println("Matricula:");
      aluno.setMatricula(teclado.next());
        
      System.out.println("Curso:");
      aluno.setCurso(teclado.next());
        
      aluno.listar();
      teclado.close();
    }
}