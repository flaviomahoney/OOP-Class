package util;

import java.util.List;
import java.util.Scanner;

import entidades.*;

public final class MinhasFormas {
	
	static double raio;
	static double lado;
	
	public static void ler(List<Forma> formas) {
		
		System.out.println("Entre com valor de formas: ");
			@SuppressWarnings("resource")
			Scanner in = new Scanner(System.in);
				
			System.out.println("Entre com o valor do Raio:");
			raio = in.nextDouble();
				
				
			System.out.println("Entre com o valor do lado:");
			lado = in.nextDouble();
		
	}

	
	public static void imprimir(List<Forma> formas) {
		
		System.out.println("Formas Geom�tricas");
		for (Forma forma : formas) {
			if(forma instanceof Circulo )
				System.out.println("Area do Circulo - " + forma.getArea());
			
			else if(forma instanceof Quadrado)
				System.out.println("Area do Quadrado - " + forma.getArea());
		}
		
	}
	
	
	
}
