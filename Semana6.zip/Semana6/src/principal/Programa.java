package principal;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import entidades.*;
import util.MinhasFormas;

public class Programa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		List<Forma> formas = new ArrayList<>();
		MinhasFormas.ler(formas);
		MinhasFormas.imprimir(formas);

	}

}
