package entidades;

public abstract class Forma {
	
	public abstract Double getArea();
}
